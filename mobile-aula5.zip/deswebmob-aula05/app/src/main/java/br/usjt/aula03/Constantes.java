package br.usjt.aula03;

public class Constantes {
    public static final long REQUEST_LOCATION_UPDATE_MIN_TIME = 2000;
    public static final long REQUEST_LOCATION_UPDATE_MIN_DISTANCE = 200;
}
